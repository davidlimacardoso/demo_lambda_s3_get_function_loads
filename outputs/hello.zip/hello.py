def hello_function(event, context):
    print("Hello Terraform")

def secondValues():
    print("Test 2")